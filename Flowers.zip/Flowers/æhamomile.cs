﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Flowers
{
    class Сhamomile : Flowers
    {
        public string Type
        {
            get
            {
                return "Сhamomile";
            }
        }
    }
}
