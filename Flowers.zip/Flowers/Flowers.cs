﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Flowers
{
    public class Flowers
    {
        public int Price { get; set; }
    }
}
