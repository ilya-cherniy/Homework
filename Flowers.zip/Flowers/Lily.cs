﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Flowers
{
    class Lily : Flowers
    {
        public string Type
        {
            get
            {
                return "Lily";
            }
        }
    }
}
