﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Flowers
{
    class Rose : Flowers
    {
        public string Type
        {
            get
            {
                return "Rose";
            }
        }

    }
}
