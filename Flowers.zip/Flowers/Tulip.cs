﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Flowers
{
    public class Tulip : Flowers
    {
        public string Type
        {
            get
            {
                return "Tulip";
            }
        }
 
    }
}
