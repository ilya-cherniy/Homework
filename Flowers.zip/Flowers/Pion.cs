﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Flowers
{
    class Pion : Flowers
    {
        public string Type
        {
            get
            {
                return "Pion";
            }
        }
    }
}
